const History = () => {

  return <div>This is History!</div>

}

export default History