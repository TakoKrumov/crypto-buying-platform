const Planing = () => {

  return <div>This is planing</div>

}

export default Planing