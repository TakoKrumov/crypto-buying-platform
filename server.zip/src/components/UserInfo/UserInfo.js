const UserInfo = () => {

  return <div>User INFO!!!</div>

}

export default UserInfo